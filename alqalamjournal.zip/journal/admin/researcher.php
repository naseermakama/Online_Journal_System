



<?php include ('session.php');?>    
<?php include ('header.php');?> 
<body>
    <div id="wrapper" style="background-color:#00802b;">
       <?php include 'top_nav.php' ?>;
       
        <!--/. NAV TOP  -->
       <?php include ('nav_sidebar.php');?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" style="background-color: white;"  >
            <div id="page-inner">
             <div class="row">
                    <div class="col-md-12">
                        
                        
                        
                        <div class="hero-unit-table">   
                            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                               <center><div class="alert alert-success">
                                    <strong><i class="icon-user icon-large"></i>&nbsp; Researcher's Table !!!</strong>
                                </div></center>
                                <thead>
                                    <tr>
                                        <th>S/N</th>
                                        <th> Name</th>
                                        <th>Phone No.</th>
                                        <th>Username</th>
                                       
                                       </tr>
                                   </thead>
                                    <?php include ('connect.php');
                                   
                                    $x = 1;
                                      $sql = "SELECT * FROM researcher";
                                     $query= mysqli_query($conn,$sql) or die(mysqli_error($conn));
                                    while ($row = mysqli_fetch_array($query)) {
                                        $id = $row['res_id'];
                                        $name = $row['res_name'];
                                        $phone = $row['res_phone'];
                                        $user = $row['res_username'];
                                          
                                                                
                                        
                                        ?>
                                        <tbody>
                                        <tr class="warning">
                                            <td><?php echo $x; ?></td> 
                                            <td><?php echo $name; ?></td>
                                            <td><?php echo $phone; ?></td>  
                                            <td><?php echo $user ?></td> 
                                        
                                    </tr> 
                                <?php $x++; } ?>
                                </tbody>
                            </table>
                  
                          
                    </div>
                </div> 
                
                
                </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
   <?php include ('script.php');?>
</body>
</html>
    