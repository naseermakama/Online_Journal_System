 
<br><br>
 <nav class="navbar-success navbar-side"  role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <a href="#"><i class="fa fa-dashboard"></i>Dashboard</a>
                    </li>
                    <li>
                        <a href="journal.php"><i class="fa fa-book"></i>Published Journal</a>
                    </li>
					
					<li>
                        <a href="process.php"><i class="fa fa-book"></i>Process Papers</a>
                        <a href="newpaper.php"><i class="fa fa-book"></i>New Papers</a>
                        <a href="reviewer.php"><i class="fa fa-user"></i>Reviewer</a>
                        <a href="author.php"><i class="fa fa-user"></i>Authors</a>
                        <a href="researcher.php"><i class="fa fa-user"></i>Researcher</a>
                    </li>
					<li>
                        <a href="logout.php"><i class="fa fa-user"></i>Log out</a>
                    </li>            
                </ul>
            </div>
        </nav>
<?PHP
// students.php = lectures.php
// department.php = tutorial
// result.php
// result. php = complaint
 ?>
