

<?php ob_start();
$page = 'Reviewer';
 ?>

<div class="modal fade" id="joke" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                          
                                            <h4 class="modal-title" id="myModalLabel"></h4>
                                        </div>
                                        <div class="modal-body">
                            <form  method="post" enctype="multipart/form-data">
                                <div class="alert alert-success"><strong><center>Add <?php echo $page ?> </center></strong></div>
                                <hr>
								
								<div class="control-group">
                                    <label class="control-label" for="inputEmail"><?php echo $page ?> Name:</label>
                                    <div class="controls">
                                        <input type="text" class = "form-control" name="name" id="inputEmail" placeholder="<?php echo $page ?> Name">
                                    </div>
                                </div>
                               	<div class="control-group">
                                    <label class="control-label" for="inputEmail"><?php echo $page ?> Username:</label>
                                    <div class="controls">
                                        <input type="text" class = "form-control" name="username" placeholder="<?php echo$page ?> Username">
                                    </div>
                                </div>
                               	  <div class="control-group">
                                    <label class="control-label" for="inputEmail"><?php echo $page ?> Phone No:</label>
                                    <div class="controls">
                                        <input type="text" class = "form-control" name="phone" placeholder="<?php echo$page ?> Username">
                                    </div>
                                </div>
                                  
                                
                                
                               	 
                               
                               
                               
								<div class = "modal-footer">
											 <button name = "add" class="btn btn-success">Add</button>
											<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                           

								</div>
							
									   </div>
                                     
                                          
                                      
                                    </div>
									
									  </form>  		  
                                </div>
                            </div>

                         <?php

		if (isset($_POST['add'])) {
			$name = $_POST['name'];
			$phone = $_POST['phone'];
      $user = $_POST['username'];
			$pass = sha1($_POST['username']);
			
      $sqlch = mysqli_query($conn,"SELECT * FROM reviewer WHERE rev_username = '$user' OR rev_number = '$phone'") or die(mysqli_error($conn));
			$chq = mysqli_num_rows($sqlch);
			
					 
                                if ($chq == 0) {
                                  $up = mysqli_query($conn, "INSERT INTO reviewer(rev_name,rev_number,rev_username,rev_pass) VALUES('$name','$phone','$user','$pass')") or die(mysqli_error($conn));
                                  if ($up) {
                                    echo "<script> alert('Reviewer Was Added Successfully...')</script>";
                                   

                                  }else{
                                    echo "<script> alert('Could not Add Reviewer Please Try Again..!!!')</script>";
                                  }
                                }else{
                                    echo "<script> alert('Reviewer Username or Phone Number Already Exist')</script>";

                                }
				// code...
			
			       
      

		}
	 ?>  
									  
							