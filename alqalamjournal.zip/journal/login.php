<?php
include 'includes/header.inc.php'

?>
<div class="col-sm-4"></div>

<div class="col-sm-4">

		<form method= "post" >
		  <div class="form-group">
		  	<h3 style="margin-bottom: 50px; font: 30px bold; color: green" >LOGIN FORM</h3>
		    <label >Username:</label>
		    <input type="text" class="form-control" id="email" name="username">
		  </div>
		  <div class="form-group">
		    <label for="pwd">Password:</label>
		    <input type="password" class="form-control" name="password" id="pwd">
		  </div>

		  <input  type="submit" name = "submit" value="submit" class="btn btn-success">
		<a href="createaccount.php">  <input  type="button" name = "submit" value="Create Account"  class="btn btn-primary"> </a>
		</form>


</div>
<div class="col-sm-4"></div>
<?php
							include('includes/connect.php');

							if(isset($_POST['submit']))
							{

							$username=$_POST['username'];
							$password=sha1($_POST['password']);
							$pass = sha1($_POST['password']);
							//   SQL QUERIES
								$sqla = mysqli_query($conn, "SELECT * FROM admin WHERE username = '$username' AND pass = '$password'") or die(mysqli_error($conn));
								$sql_auth = mysqli_query($conn, "SELECT * FROM author WHERE auth_username = '$username' AND auth_pass = '$pass' ") or die(mysqli_error($conn)) ;
								$sql_res = mysqli_query($conn, "SELECT * FROM researcher WHERE res_username = '$username' AND res_pass = '$password'") or die(mysqli_error($conn));
								$sql_rev = mysqli_query($conn, "SELECT * FROM reviewer WHERE rev_username = '$username' AND rev_pass = '$pass' ") or die(mysqli_error($conn)) ;

								// Fetch array
								$row = mysqli_fetch_array($sqla);
								$row_auth = mysqli_fetch_array($sql_auth);
								$row_res = mysqli_fetch_array($sql_res);
								$row_rev = mysqli_fetch_array($sql_rev);

								// check row number
								$num = mysqli_num_rows($sqla);
								$num_auth = mysqli_num_rows($sql_auth);
								$num_res = mysqli_num_rows($sql_res);
								$num_rev = mysqli_num_rows($sql_rev);
								//$numberOfRows_applicant = mysqli_num_rows($result_applicant);


						if ($num > 0)	{
																		session_start();
																	$_SESSION['id'] = $row['aid'];

																header("Location:admin/journal.php");

				}else if ($num_auth > 0) {
																unset($_SESSION['id']);
																session_start();
																$_SESSION['auth_id'] = $row_auth['auth_id'];
																header("Location:auth_index.php");
					}else if ($num_rev > 0) {
																unset($_SESSION['auth_id']);
																session_start();
																$_SESSION['rev_id'] = $row_rev['rev_id'];
																header("Location:rev_index.php");
					}else if ($num_res > 0) {
																unset($_SESSION['rev_id']);
																session_start();
																$_SESSION['res_id'] = $row_res['res_id'];
																header("Location:res_index.php");
					}

					else{

																echo " <br><center><font color= 'red' size='3'>Invalid Username or Password </center></font>";
																ECHO ($pass);

															}

							}
							?>
