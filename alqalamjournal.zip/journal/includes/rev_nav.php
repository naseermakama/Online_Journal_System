<?php include 'session.php'; ?>
<!DOCTYPE html>
<html>
<head>
  <title>Journal Management System</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/w3.css">
<link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<!-- <link rel="stylesheet" href="../css/bootstrap.min.css"> -->
 <link rel="stylesheet"  href="fontawesome/web-fonts-with-css/css/fontawesome-all.min.css">
 <style type="text/css">
    li a{
    font: 15px bold tahoma ;
    color: white;
  }
  li{
    font-style: none;
    font: 20px bold tahoma;
    list-style: none;

  }

   
 </style>

 <div class="logo" style=" margin-bottom:3px;height:100px; background-color:white;">
 <h3 align="center" style="margin-top:0px; color:green; margin-left:30px;" >    <img src="includes/ssu.png" width="100px">Journal Management System  </h3>
  </div>
 <!-- Navbar for larger screen like pc and destops-->

<nav>

<ul class="w3-navbar  w3-text-white w3-card-2 w3-left-align"  style="background-color:green; padding:5px;">
  
  <li><a href="#" class="w3-hover-none w3-right w3-hover-text-grey w3-padding-large"><i class="fa fa-home"></i></a></li>
    <li class="w3-hide-small w3-right"><a href="logout.php" class="w3-padding-large"> Logout </a></li>
   
    <li class="w3-hide-small w3-right"><a href="process.php" class="w3-padding-large"> Approved Journal</a></li>
   <li class="w3-hide-small w3-right"><a href="review.php" class="w3-padding-large">My Assigned Journal</a></li>
   <li class="w3-hide-small w3-right"><a href="rpublished.php" class="w3-padding-large">My Published Journal</a></li>
  
       
</ul>
</div>


</nav>
    
</html>
