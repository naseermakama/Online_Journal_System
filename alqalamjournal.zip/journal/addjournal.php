<?php include 'includes/headers.php';
//  include 'includes/header.inc.php';
include 'connect.php';
$sql = mysqli_query($conn, "SELECT * FROM author WHERE auth_id = $ses_id") or die(mysqli_error($conn));
$row = mysqli_fetch_assoc($sql);
$name = $row['auth_name'];
$au_id = $row['auth_id'];
$page = 'Author';
?>

   <center><h3 style="margin-bottom: 50px; font: 30px bold; color: green; "> Upload New Journal  </h3></center>
<form method="post" enctype="multipart/form-data">

<div class="col-sm-3"></div>
<div class="col-sm-5">


  <div class="form-group">
    <label for="email"><?php echo $page ?> NAME:</label>
    <input type="text" class="form-control" name="fname" required="" value="<?php echo $name ?>" readonly >
  </div>
  <div class="form-group">
    <label for="Phone">Paper Name:</label>
    <input type="text" class="form-control" name="paper" required >
  </div>
 <div class="form-group">
    <label for="email">Paper Title:</label>
    <input type="text" class="form-control" name="title" required  >
  </div>
  

<div class="form-group">
    <label for="email">Upload Paper:</label>
    <input type="file"  class="form-control" name="cv">
  </div>
  <input type="submit" name="submit" style="margin-left:500px; margin-top: 20px;" class="btn btn-success" value="Upload Journal"  >
</form>
</div>
 <div class="col-sm-3"></div>




<?php



                            if (isset($_POST['submit'])) {
                              $pep = $_POST['paper'];
                              $tlt = $_POST['title'];
  $cv = addslashes(file_get_contents($_FILES['cv']['tmp_name']));
                   $cv_name = addslashes($_FILES['cv']['name']);
                                $cv_size = $_FILES['cv']['size'];
                                $cv_type = $_FILES['cv']['type'];
$extension = substr($cv_name, strpos($cv_name,'.') + 1);
      if($extension == 'pdf'){
                  $i = move_uploaded_file($_FILES["cv"]["tmp_name"], "upload/" . $tlt.'.'.$extension);
                                $location = "upload/" . $tlt. '.'.$extension;
                                if ($i) {
                                  $up = mysqli_query($conn, "INSERT INTO paper(pep_title,pep_name,dir,au_id) VALUES('$tlt','$pep','$location','$ses_id')") or die(mysqli_error($conn));
                                  if ($up) {
                                    echo "<script> alert('paper uploaded Successfull...')</script>";
                                    header('Location:newjournal.php');

                                  }else{
                                    echo "<script> alert('Could not update paper location')</script>";
                                  }
                                }else{
                                    echo "<script> alert('Could not upload Paper')</script>";

                                }
      }else{
        echo "<script> alert('Only Pdf File Are Allowed')</script>";
      }
             
}
?>