


 <nav class="navbar navbar-default top-navbar" style="background: #fff; height: 150px;" role="navigation">

 <div class="header" style=" margin-bottom:3px;height:100px; background-color:white;">
   <h2 align="center" style="margin-top:50px; color:green; margin-left:0px; font-family: arial;" > <img src="../includes/ssu.png" width="100px"  style="padding-left: 0px; "> <small> <marquee> ADMIN Page E-journal </marquee> </small> </h2><P></P>
  </div>

        </nav>
