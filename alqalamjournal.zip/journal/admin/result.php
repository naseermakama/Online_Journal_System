



<?php include ('session.php');?>	
<?php include ('header.php');?>	
<body>
    <div id="wrapper" style="background-color: #00802a;">
       <?php include ('top_nav.php');?>
       
        <!--/. NAV TOP  -->
       <?php include ('nav_sidebar.php');?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" style="background-color: white;" >
            <div id="page-inner">
			 <div class="row">
                    <div class="col-md-12">
						
                      
						<div class="hero-unit-table">   
                             <table class="table table-striped table-bordered table-hover table-condensed" id="dataTables-example">
                                <div class="alert alert-success">
                                    <center><strong><i class="icon-user icon-large"></i>&nbsp;Applicants</strong></center>
                                </div>
								    <ul class="breadcrumb"> 
										<li>Student Result/</li>				
									
									
									</ul>
                                <thead>
                                    <tr>
                                        <th>S/N</th>
                                        <th>ADM NO.</th>
                                        <th>Fullname</th>
                                        <th>Score</th>
                                        <th>Status</th>
										
                                    </tr>
                                </thead>
                                <tbody>
                                     <?php include ('connect.php');
                                    $cart_table = mysqli_query($conn, "SELECT * FROM tblstudent") or die(mysqli_error($conn));
                                    $cart_count = mysqli_num_rows($cart_table);
                                    $x = 1;
                                    while ($cart_row = mysqli_fetch_array($cart_table)) {
                                        $adm = $cart_row['ADNo'];
                                        $name = $cart_row['FName']." ".$cart_row['LName'];
                                        $score = $cart_row['st_score'];
                                        $statu = $cart_row['status'];
                                       if($statu == 1){
                                        $status = 'SUBMITTED';
                                       }else{
                                        $status = "NOT SUBMITTED YET";
                                       }
                                       ?>

                                        <tr>
                                           
                                            <td><?php echo $x; ?></td>
                                            <td><?php echo $adm; ?></td>
                                            <td><?php echo $name; ?></td>
                                            <td><?php echo $score; ?></td>
                                            <td><?php echo $status; ?></td>
                                           
											
                                        </tr>
                                            
                                            
                                           
                                            <!-- product delete modal -->
                                  
                                    <!-- end delete modal -->

                                    </tr>
                                <?php $x++; } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div> 
                
				
				</div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
   <?php include ('script.php');?>
</body>
</html>


 