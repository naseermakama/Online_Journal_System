



<?php include ('session.php');?>    
<?php
include('header.php');
$get_id = $_GET['id'];
ob_start();
?>
<body>
    <div id="wrapper" style="background-color:#00802b;">
     <?php include 'top_nav.php'; ?>
        <!--/. NAV TOP  -->
       <?php include ('nav_sidebar.php');?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" style="background-color:white;" >
            <div id="page-inner">
             <div class="row">
                    <div class="col-md-5 well">
                        <div class="hero-unit-table">   
                          <div class="hero-unit-table">   
                            <?php include ('connect.php');
                            $sql = "SELECT * FROM paper  p INNER JOIN author a ON p.au_id = a.auth_id  WHERE status = 'Pending' AND pep_id = $get_id";
                                    
                                     $query= mysqli_query($conn,$sql) or die(mysqli_error($conn));
                            $row = mysqli_fetch_array($query);
                        
                             $id = $row['pep_id'];
                                        $title = $row['pep_title'];
                                        $pname = $row['pep_name'];
                                        $status = $row['status'];
                                     
                                        $author = $row['auth_name'];
                            ?>
                                     <form  method="post"  id="loginForm">
                                
                                <hr>
                                
                               

  <div class="form-group">
    <label for="text">Paper:</label>
    <input type="text" class="form-control" name="pname" value="<?php echo $pname; ?>" readonly >
  </div>
  <div class="form-group">
    <label for="Phone">Paper Title:</label>
    <input type="text" class="form-control" name="title" readonly value="<?php echo $title; ?>" >
  </div>
 <div class="form-group">
    <label for="score">Author:</label>
    <input type="text" class="form-control" name="author" value="<?php echo $author; ?>" readonly  >
  </div>
 <div class="form-group">
    <label for="score">Assign Reviewer:</label>
   <select class="form-control" name="rev">
     <?php
     $sqlr = mysqli_query($conn, "SELECT * FROM reviewer") or die(mysqli_error($conn));
     while ($rowr = mysqli_fetch_array($sqlr)) {?>
     <option value="<?php echo $rowr['rev_id'] ?>"><?php echo $rowr['rev_name'] ?></option>
       
     <?php }
      ?>
   </select>
  </div>




                                <div class = "modal-footer">
                                    <button name = "update" class="btn btn-success ">Update</button>
                                  
                                           

                                </div>
                            
                                       </div>
                
                                          
                                      
                                    </div>
                                    
                                      </form>  
                            <?php 
                            
                            if (isset($_POST['update'])) {

                                
                                $rev = $_POST['rev'];
                               
                               
                             
                                $ass = mysqli_query($conn, "UPDATE paper set re_id = '$rev', status = 'Assigned' where pep_id ='$id'") or die(mysqli_error($conn));
                                if ($ass) {
                                  header('location:journal.php');
                                }else{
                                  echo "<script> alert('Couldnot Assigned Reviewr')</script>";
                                }
                                
                               
                            }
                            ?>


                        </div>
                        </div>
                        </div>
                    </div>
                </div> 
                
                
                </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
   <?php include ('script.php');?>
</body>
</html>
<script src="js/jquery.min.js" type="text/javascript"></script>
        <script src="js/jquery.maskedinput.js" type="text/javascript"></script>
        <script>
        jQuery(function($){
        $("#nic").mask("99999-9999999-9");
        $("#date").mask("99/99/9999");
        $("#phone").mask("(999) 999-999-99");
        $("#ext").mask("(999) 999-9999? Ext.99999");
        $("#mobil").mask("+2349999999999");
        $("#admn").mask("9999999999");

        $("#apno").mask("99999999999");
        $("#score").mask("99");
        $("#percent").mask("99%");
        $("#productkey").mask("a*-999-a999");
        $("#orderno").mask("PO: aaa-999-***");
        $("#date2").mask("99/99/9999", { autoclear: false });
        $("#date3").mask("99/99/9999", { autoclear: false, completed:function(){alert("Completed!");} });
        $("#mobile2").mask("+1 999 999 999");
        });
      </script>