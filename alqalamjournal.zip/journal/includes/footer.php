<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/w3.css">
 <link rel="stylesheet"  href="fontawesome/web-fonts-with-css/css/fontawesome-all.min.css">
	<style type="text/css">
		.footer{
	
	text-align: center;
	color:white;
}p{
margin-top:-10px;
color:white;
}
</style>
</head>
<body>
	
 <div class="footer" style="background-color:green;"><br><p>&copy<?php echo date("Y")?> UNIVERSAL</p></p></div>
</body>
</html>