<?php include 'includes/applicantheader.php';
//  include 'includes/header.inc.php';
include 'connect.php';
$get_id = $_GET['applicant'];
$query = mysqli_query($conn, "SELECT * FROM staff WHERE st_id = '$get_id' ");
$row = mysqli_fetch_array($query);
$file = $row['staff_id'];
$name = $row['s_name'];
$phone = $row['s_phone'];
$email = $row['email'];
$date = $row['dates'];
?>

   <center><h3 style="margin-bottom: 50px; font: 30px bold; color: green; "> Applicant Qualifications </h3></center>
<form method="post" enctype="multipart/form-data">

<div class="col-sm-3"></div>
<div class="col-sm-5">

<div class="form-group">
   <h3 style=" font: 25px bold; color: green; "> Personal Information </h3>

    <label for="e">Staff ID:</label>
    <input type="text" class="form-control" name="staff_id" id="staffid" value="<?php echo $file ?>" readonly required>
  </div>
  <div class="form-group">
    <label for="email">FULL NAME:</label>
    <input type="text" class="form-control" name="fname" required="" value="<?php echo $name ?>" readonly >
  </div>
  <div class="form-group">
    <label for="Phone">Phone no:</label>
    <input type="text" class="form-control" name="phone" id="mobil" required value="<?php echo $phone ?>" readonly >
  </div>
 <div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" class="form-control" id="email" name="email" required value="<?php echo $email ?>" readonly >
  </div>
  
    
      <div class="form-group">

  <label for="email">Date Of Confirmation  :</label>
    <input type="date" name="date" class="form-control" value="<?php echo $date ?>" readonly >
  </div>

<div class="form-group">
    <label for="email">Upload Credentials:</label>
    <input type="file"  class="form-control" name="cv">
  </div>
  <input type="submit" name="submit" style="margin-left:500px; margin-top: 20px;" class="btn btn-success" value="Upload CV"  >
</form>
</div>
 <div class="col-sm-3"></div>




<?php



                            if (isset($_POST['submit'])) {

  $cv = addslashes(file_get_contents($_FILES['cv']['tmp_name']));
                   $cv_name = addslashes($_FILES['cv']['name']);
                                $cv_size = $_FILES['cv']['size'];
                                $cv_type = $_FILES['cv']['type'];
$extension = substr($cv_name, strpos($cv_name,'.') + 1);
      if($extension == 'pdf'){
                  $i = move_uploaded_file($_FILES["cv"]["tmp_name"], "upload/" . $file);
                                $location = "upload/" . $file;
                                if ($i) {
                                  $up = mysqli_query($conn, "UPDATE promotion SET cv = '$location' WHERE staff_id = '$get_id'") or die(mysqli_error($conn));
                                  if ($up) {
                                    echo "<script> alert('CV uploaded Successfull...')</script>";
                                    header('Location:applicant_home.php');

                                  }else{
                                    echo "<script> alert('Could not update CV location')</script>";
                                  }
                                }else{
                                    echo "<script> alert('Could not upload CV')</script>";

                                }
      }else{
        echo "<script> alert('Only Pdf File Are Allowed')</script>";
      }
             
}
?>