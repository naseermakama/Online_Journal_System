<?php
include 'includes/header.inc.php'

?>
 <style type="text/css">
 	.main{
	margin-top:0px;
	height: 500px;
	width: 100%;

background-image:url('includes/alqalam.jpg') ;


}
 </style>
    <div class="main" style="	">
    </div>
<?php // include 'footer.inc.php'; ?>
