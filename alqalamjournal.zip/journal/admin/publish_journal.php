<?php
include('connect.php');

$get_id=$_GET['id'];

mysqli_query($conn,"UPDATE paper SET status = 'Published'  WHERE pep_id='$get_id'")or die(mysqli_error($conn));
header('location:journal.php');
?>
