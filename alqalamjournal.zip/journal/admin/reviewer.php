



<?php include ('session.php');?>	
<?php include ('header.php');?>	
<body>
    <div id="wrapper" style="background-color:#00802b;">
       <?php include 'top_nav.php' ?>;
       
        <!--/. NAV TOP  -->
       <?php include ('nav_sidebar.php');?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" style="background-color: white;"  >
            <div id="page-inner">
			 <div class="row">
                    <div class="col-md-12">
                        
						  <h1 class="page-header">
                           
                             <center><button class="btn btn-success btn-lg" data-toggle="modal" data-target="#joke">
                              Add Reviewer
                            </button></center>
                            
                        
                        </h1>
                        <?php include ('addrev.php');?>
                        
						
						<div class="hero-unit-table">   
                            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                               <center><div class="alert alert-success">
                                    <strong><i class="icon-user icon-large"></i>&nbsp; Reviewer Table !!!</strong>
                                </div></center>
                                <thead>
                                    <tr>
                                        <th>S/N</th>
                                        <th> Name</th>
                                        <th>Phone No.</th>
                                        <th>Username</th>
                                        <th>Action</th>
                                       </tr>
                                   </thead>
                                    <?php include ('connect.php');
                                   
                                    $x = 1;
                                      $sql = "SELECT * FROM reviewer";
                                     $query= mysqli_query($conn,$sql) or die(mysqli_error($conn));
                                    while ($row = mysqli_fetch_array($query)) {
                                        $id = $row['rev_id'];
                                        $name = $row['rev_name'];
                                        $phone = $row['rev_number'];
                                        $user = $row['rev_username'];
										  
																
										
                                        ?>
                                        <tbody>
                                        <tr class="warning">
                                            <td><?php echo $x; ?></td> 
                                            <td><?php echo $name; ?></td>
                                            <td><?php echo $phone; ?></td>  
                                            <td><?php echo $user ?></td> 
                                            
                                           
                                            <td width="170">

                                                <a href="#delete_reviewer<?php echo $id; ?>" role="button"  data-target = "#delete_reviewer<?php echo $id;?>"data-toggle="modal" class="btn btn-danger"><i class="icon-trash icon-large"></i>&nbsp;Delete</a>


                                               

                                            </td>
                                            <!-- student delete modal -->
                                   <?php include ('delete_reviewer_modal.php');?>
                                    <!-- end delete modal -->

                                    </tr> 
                                <?php $x++; } ?>
                                </tbody>
                            </table>
                  
                          
                    </div>
                </div> 
                
				
				</div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
   <?php include ('script.php');?>
</body>
</html>
    