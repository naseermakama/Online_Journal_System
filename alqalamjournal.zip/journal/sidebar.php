



 <div class="contact">
                        <ul>
                            <li class="address">
                                <span>Address</span>
                                <ul>
                                    <li>
									<i class = "icon icon-home"></i>
									<p>SMFarm </p>
									<p>Arkillah Bypass ,Sokoto State Nigeria</p>
                                    </li>
                                  
                                
                                </ul>
                            </li>
                            <li class="contactInfo">
								
									<i class = "icon icon-user"></i>
                                <ul>
                                    <li>
                                        +2348106207852
                                    </li>
                                    <li>
                                        +2348106207852
                                    </li>
                                </ul>
                            </li>
                            <li class="mail">
                                <i class = "icon icon-envelope"> </i>
                                <ul>
                                    <li>
                                        <a href="#">musaiyyibtukur@gmail.com</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                   