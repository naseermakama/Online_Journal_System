



<?php include ('session.php');?>
<?php include ('header.php');?>
<body>
    <div id="wrapper" style="background-color:#00802b;">
       <?php include 'top_nav.php' ?>;

        <!--/. NAV TOP  -->
       <?php include ('nav_sidebar.php');?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" style="background-color: white;"  >
            <div id="page-inner">
			 <div class="row">
                    <div class="col-md-12">



						<div class="hero-unit-table">
                            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                               <center><div class="alert alert-success">
                                    <strong><i class="icon-user icon-large"></i>&nbsp; New Journals !!!</strong>
                                </div></center>
                                <thead>
                                    <tr>
                                        <th>S/N</th>
                                        <th> Name</th>
                                        <th>Paper Title</th>
                                        <th>Author</th>
                                        <th>Status</th>
                                        <th>Action</th>

                                       </tr>
                                   </thead>
                                    <?php include ('connect.php');

                                    $x = 1;
                                      $sql = "SELECT * FROM paper  p INNER JOIN author a ON p.au_id = a.auth_id  WHERE status = 'Pending'";
                                     $query= mysqli_query($conn,$sql) or die(mysqli_error($conn));
                                    while ($row = mysqli_fetch_array($query)) {
                                        $id = $row['pep_id'];
                                        $title = $row['pep_title'];
                                        $pname = $row['pep_name'];
                                        $status = $row['status'];

                                        $author = $row['auth_name'];



                                        ?>
                                        <tbody>
                                        <tr class="warning">
                                            <td><?php echo $x; ?></td>
                                            <td><?php echo $pname; ?></td>
                                            <td><?php echo $title; ?></td>

                                            <td><?php echo $author ?></td>
                                            <td><?php echo $status ?></td>


                                            <td width="170">

                                                <a href="assign.php<?php echo '?id='.$id; ?>"  class="btn btn-danger"><i class="icon-trash icon-large"></i>&nbsp;Assign</a>




                                            </td>
                                            <!-- student delete modal -->

                                    </tr>
                                <?php $x++; } ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>


				</div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
   <?php include ('script.php');?>
</body>
</html>
