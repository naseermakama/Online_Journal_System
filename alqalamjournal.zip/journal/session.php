



<?php
session_start();
if (isset($_SESSION['id'])){
$ses_id = $_SESSION['id'];

}else if(isset($_SESSION['auth_id'])){
	$ses_id = $_SESSION['auth_id'];
}else if(isset($_SESSION['rev_id'])){
	$ses_id = $_SESSION['rev_id'];
}else if(isset($_SESSION['resh_id'])){
	$ses_id = $_SESSION['res_id'];
}else{
header('location:login.php');
	
}

?>