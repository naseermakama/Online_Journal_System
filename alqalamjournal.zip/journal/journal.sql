-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 03, 2023 at 10:02 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `journal`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `aid` int(11) NOT NULL,
  `username` varchar(33) NOT NULL,
  `pass` varchar(55) NOT NULL,
  `fullname` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aid`, `username`, `pass`, `fullname`) VALUES
(1, 'chocker', 'd799970799a13cbc7c8c5b02e2df0e41596ec88a', 'Abubakar aminu');

-- --------------------------------------------------------

--
-- Table structure for table `author`
--

CREATE TABLE `author` (
  `auth_id` int(11) NOT NULL,
  `auth_name` varchar(55) NOT NULL,
  `auth_pass` varchar(55) NOT NULL,
  `auth_phone` int(22) NOT NULL,
  `auth_username` varchar(44) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `author`
--

INSERT INTO `author` (`auth_id`, `auth_name`, `auth_pass`, `auth_phone`, `auth_username`) VALUES
(1, 'Abubakar ibrahim sayyadi', '27c0976a0bceacad68eb31d7e090f4efc2c0e3b3', 33333, 'sayyadi'),
(2, 'usky', 'a5611ae6f2e2d341d80447e5af8e7efd1f94eb57', 0, '44322'),
(3, 'ameen', '150151b9e916d6c60e7b0638e2495ffcce87c64f', 3322, 'ameenu ibrahim'),
(4, 'Abdull madjee nasir', 'f48a17a30a8a3ce383dc2619cfa35fd419f0ea03', 32323, 'mnasir'),
(5, 'Ameenu Aliyu Anka', 'b53c5ffa102057fe36b7abec12a6af3d0e741d13', 40405, 'anka');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `comm_id` int(11) NOT NULL,
  `comments` varchar(2222) NOT NULL,
  `res_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `download`
--

CREATE TABLE `download` (
  `did` int(11) NOT NULL,
  `rid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `dates` varchar(77) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `paper`
--

CREATE TABLE `paper` (
  `pep_id` int(11) NOT NULL,
  `pep_title` varchar(55) NOT NULL,
  `au_id` int(11) NOT NULL,
  `re_id` int(11) NOT NULL,
  `pep_name` varchar(33) NOT NULL,
  `dir` varchar(44) NOT NULL,
  `img_dir` varchar(55) NOT NULL,
  `status` varchar(22) NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `paper`
--

INSERT INTO `paper` (`pep_id`, `pep_title`, `au_id`, `re_id`, `pep_name`, `dir`, `img_dir`, `status`) VALUES
(1, 'system testing and implementation', 1, 1, 'software engineering', 'files/', '', 'Assigned'),
(2, 'operating system', 1, 1, 'deadlock theory', 'upload/operating system.pdf', '', 'Assigned'),
(3, 'Introduction to PHP', 5, 1, 'Web Devellopment', 'upload/Introduction to PHP.pdf', '', 'Published'),
(4, 'Introduction to CSS', 5, 2, 'Web Devellopment', 'upload/Introduction to CSS.pdf', '', 'Published'),
(5, 'Introduction to logo Design', 5, 1, 'Graphics Design ', 'upload/Introduction to logo Design.pdf', '', 'Assigned'),
(6, 'in troductio to w3 CSS', 5, 1, 'Web Design', 'upload/in troductio to w3 CSS.pdf', '', 'Pending'),
(7, 'eeww', 5, 1, 'Web Devellopments', 'upload/eeww.pdf', '', 'Assigned'),
(8, 'sddadfad', 5, 1, 'Graphics Design sd', 'upload/sddadfad.pdf', '', 'Published'),
(9, 'aldkj', 1, 0, 'afkdsj', 'upload/aldkj.pdf', '', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `researcher`
--

CREATE TABLE `researcher` (
  `res_id` int(11) NOT NULL,
  `res_name` varchar(55) NOT NULL,
  `res_pass` varchar(55) NOT NULL,
  `res_username` varchar(22) NOT NULL,
  `res_phone` varchar(33) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `researcher`
--

INSERT INTO `researcher` (`res_id`, `res_name`, `res_pass`, `res_username`, `res_phone`) VALUES
(1, 'Zayyanu Yusuf ', 'b737a478bc7cb39084e007a45c55009eb19da8a3', 'dangayu', '9988999'),
(2, 'Xarah Bunza', 'faty', 'faty', '+2348944884738'),
(3, 'SHAMSUDDEEN MUAZU', '8e6eef7631914842e9bea8735aeb7fa21afdbfc5', 'Abba ', '+2340803880760'),
(4, 'Adamu Muhammad', 'bf9661defa3daecacfde5bde0214c4a439351d4d', 'sss', '+2342223333333'),
(5, 'Yasir Muhammad Tsiga', '7a68d92b62b46967a0b087e201ef682493ec45ae', 'Yasir', '+2348123456789');

-- --------------------------------------------------------

--
-- Table structure for table `reviewer`
--

CREATE TABLE `reviewer` (
  `rev_id` int(11) NOT NULL,
  `rev_name` varchar(55) NOT NULL,
  `rev_number` varchar(22) NOT NULL,
  `rev_pass` varchar(55) NOT NULL,
  `rev_username` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reviewer`
--

INSERT INTO `reviewer` (`rev_id`, `rev_name`, `rev_number`, `rev_pass`, `rev_username`) VALUES
(1, 'Mustafa Sani', '444443', '867521f0913557dc0d3a6b2b1b54d48e6f1613dc', 'musty'),
(3, 'Abdul Axeex Aliyu ', 'namadina', 'd2b40efc88a5d8c9710eec94e204863fc5683e9d', 'namadina');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `author`
--
ALTER TABLE `author`
  ADD PRIMARY KEY (`auth_id`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`comm_id`);

--
-- Indexes for table `download`
--
ALTER TABLE `download`
  ADD PRIMARY KEY (`did`);

--
-- Indexes for table `paper`
--
ALTER TABLE `paper`
  ADD PRIMARY KEY (`pep_id`);

--
-- Indexes for table `researcher`
--
ALTER TABLE `researcher`
  ADD PRIMARY KEY (`res_id`);

--
-- Indexes for table `reviewer`
--
ALTER TABLE `reviewer`
  ADD PRIMARY KEY (`rev_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `author`
--
ALTER TABLE `author`
  MODIFY `auth_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `comm_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `download`
--
ALTER TABLE `download`
  MODIFY `did` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `paper`
--
ALTER TABLE `paper`
  MODIFY `pep_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `researcher`
--
ALTER TABLE `researcher`
  MODIFY `res_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `reviewer`
--
ALTER TABLE `reviewer`
  MODIFY `rev_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
