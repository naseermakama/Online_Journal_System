



<?php include ('session.php');?>	
<?php include ('header.php');?>	
<body>
    <div id="wrapper" style="background-color:#00802b;">
       <?php include 'top_nav.php' ?>;
       
        <!--/. NAV TOP  -->
       <?php include ('nav_sidebar.php');?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" style="background-color: white;"  >
            <div id="page-inner">
			 <div class="row">
                    <div class="col-md-12">
                        
						
						
						<div class="hero-unit-table">   
                            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                               <center><div class="alert alert-success">
                                    <strong><i class="icon-user icon-large"></i>&nbsp; Published Journal !!!</strong>
                                </div></center>
                                <thead>
                                    <tr>
                                        <th>S/N</th>
                                        <th> Name</th>
                                        <th>Paper Title</th>
                                        <th>Reviewer</th>
                                        <th>Author</th>
                                        <th>Status</th>
                                       
                                    <?php include ('connect.php');
                                   
                                    $x = 1;
                                      $sql = "SELECT * FROM paper  p INNER JOIN author a ON p.au_id = a.auth_id INNER JOIN reviewer r  ON p.re_id = r.rev_id WHERE status = 'Published' ";
                                     $query= mysqli_query($conn,$sql) or die(mysqli_error($conn));
                                    while ($row = mysqli_fetch_array($query)) {
                                        $id = $row['pep_id'];
                                        $title = $row['pep_title'];
                                        $pname = $row['pep_name'];
                                        $status = $row['status'];
                                        $reviewer = $row['rev_name'];
                                        $author = $row['auth_name'];
										  
																
										
                                        ?>
                                        <tr class="warning">
                                            <td><?php echo $x; ?></td> 
                                            <td><?php echo $pname; ?></td>
                                            <td><?php echo $title; ?></td>  
                                            <td><?php echo $reviewer ?></td> 
                                            <td><?php echo $author ?></td> 
                                            <td><?php echo $status ?></td> 
                                            
                                           
                                            
                                            <!-- student delete modal -->
                                  
                                    </tr> 
                                <?php $x++; } ?>
                                </tbody>
                            </table>
                        </div>
                          
                    </div>
                </div> 
                
				
				</div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
   <?php include ('script.php');?>
</body>
</html>
