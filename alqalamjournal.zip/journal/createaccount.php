<?php
 include 'includes/header.inc.php';
 //include 'includes/functions.inc.php';
include 'connect.php';
ob_start();
?>
<div class="col-sm-3"></div>
                                        <div class="col-md-6">
                            <form  method="post" enctype="multipart/form-data">
                                <div class="alert alert-success"><strong><center>Create Account </center></strong></div>
                                <hr>

  <div class="form-group">
    <label for="email">FULLNAME:</label>
    <input type="text" class="form-control" name="fname" required="" >
  </div>


  <div class="form-group">
    <label for="Phone">Phone no:</label>
    <input type="text" class="form-control" name="phone" id="mobil" required >
  </div>
   <div class="form-group">
    <label for="username">USER NAME:</label>
    <input type="text" class="form-control" name="sname" required="" >
  </div>



                <div class = "modal-footer">
                       <button name = "add" class="btn btn-success">Create Account</button>
                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>


                </div>


                    </form>


</div>
<div class="col-sm-3"></div>

<?php
  $data = array();

                            if (isset($_POST['add'])) {

                                 $data['fname'] = $_POST['fname'];
                                $data['uname'] = $_POST['sname'];
                                 $data['phone'] = $_POST['phone'];


                                        $sql = "SELECT * FROM researcher  WHERE res_username = '".$data['uname']."' OR res_phone = '".$data['phone']."' ";
                                        $check = mysqli_query($conn, $sql ) or die(mysqli_error($conn));
                                        $ch = mysqli_num_rows($check);
                                        $fname = $data['fname'];
                                        $user = $data['uname'];
                                        $phone = $data['phone'];
                                        $pass = $data['uname'];
                                        $cpass = $data['uname'];

                                        if ($pass == $cpass) {
                                          # code...

                                        if ($ch==0){
                                          $passs = sha1($pass);
  $d = mysqli_query($conn,"INSERT INTO
    researcher ( res_phone, res_name, res_pass, res_username)
 VALUES ('$phone','$fname','$passs','$user')") or die(mysqli_error($conn));

                                               if ($d) {

                                                    echo "<script> alert('  Account was created successfully ...') </script>";


                                                     header('location:index.php');
                                                                                               }



                                        }else{
                                        echo "<script>alert('Warning : Duplicate phone number,username or admno  are not allowed')</script>";

                                        }
                                      }else{
                                        echo "<script>alert('Warning : password miss match')</script>";
                                      }


                            }
                            ?>



             <script src="admin/js/jquery.min.js" type="text/javascript"></script>
        <script src="admin/js/jquery.maskedinput.js" type="text/javascript"></script>
        <script>
        jQuery(function($){
        $("#nic").mask("99999-9999999-9");

        $("#sess").mask("9999/9999");
        $("#ext").mask("(999) 999-9999? Ext.99999");
        $("#mobil").mask("+2349999999999");
        $("#admn").mask("9999999999");

        $("#apno").mask("99999999999");
        $("#hno").mask("99");
        $("#percent").mask("99%");
        $("#productkey").mask("a*-999-a999");
        $("#orderno").mask("PO: aaa-999-***");
        $("#date2").mask("99/99/9999", { autoclear: false });
        $("#date3").mask("99/99/9999", { autoclear: false, completed:function(){alert("Completed!");} });
        $("#mobile2").mask("+1 999 999 999");
        });
      </script>
